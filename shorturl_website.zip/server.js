import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/shorten", async (req, res) => {
  try {
    const apiKey = process.env.SAFELINKU_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "API key belum diatur di file .env." });
    }

    const { url } = req.body ?? {};
    if (typeof url !== "string" || !url.trim()) {
      return res.status(400).json({ error: "Masukkan URL terlebih dahulu." });
    }

    let parsed;
    try {
      parsed = new URL(url.trim());
    } catch {
      return res.status(400).json({ error: "Format URL tidak valid." });
    }
    if (!["http:", "https:"].includes(parsed.protocol)) {
      return res.status(400).json({ error: "URL harus menggunakan http atau https." });
    }

    const upstream = await fetch("https://safelinku.com/api/v1/links", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({ url: parsed.toString() })
    });

    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); }
    catch { data = { message: raw || "Respons API tidak dapat dibaca." }; }

    if (!upstream.ok) {
      return res.status(upstream.status).json({
        error: data?.message || data?.error || `Safelinku API mengembalikan status ${upstream.status}`,
        details: data
      });
    }

    return res.status(200).json(data);
  } catch (error) {
    console.error("Shorten error:", error);
    return res.status(502).json({ error: "Tidak dapat menghubungi layanan Safelinku." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Website berjalan di http://localhost:${port}`));
const form = document.querySelector("#shorten-form");
const input = document.querySelector("#url-input");
const button = document.querySelector("#submit-btn");
const message = document.querySelector("#message");
const result = document.querySelector("#result");
const shortUrl = document.querySelector("#short-url");
const originalUrl = document.querySelector("#original-url");
const copyBtn = document.querySelector("#copy-btn");
const copyStatus = document.querySelector("#copy-status");

document.querySelector("#year").textContent = new Date().getFullYear();

function findShortUrl(data) {
  const candidates = [
    data?.short_url, data?.shortUrl, data?.short_link, data?.shortLink,
    data?.link, data?.url, data?.data?.short_url, data?.data?.shortUrl,
    data?.data?.short_link, data?.data?.link, data?.data?.url
  ];
  return candidates.find(value => typeof value === "string" && /^https?:\\/\\//i.test(value));
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";
  message.className = "message";
  result.hidden = true;
  button.disabled = true;
  button.querySelector("span").textContent = "Memproses...";

  try {
    const response = await fetch("/api/shorten", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: input.value.trim() })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || data.message || "Gagal membuat short URL.");

    const generated = findShortUrl(data);
    if (!generated) {
      console.error("Respons Safelinku:", data);
      throw new Error("Link berhasil diproses, tetapi format respons API belum dikenali. Periksa Console/server log dan sesuaikan findShortUrl() dengan respons Safelinku.");
    }

    shortUrl.href = generated;
    shortUrl.textContent = generated;
    originalUrl.textContent = `URL asli: ${input.value.trim()}`;
    result.hidden = false;
    message.textContent = "Link berhasil dibuat.";
    message.className = "message success";
  } catch (error) {
    message.textContent = error.message || "Terjadi kesalahan. Coba lagi.";
  } finally {
    button.disabled = false;
    button.querySelector("span").textContent = "Persingkat";
  }
});

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(shortUrl.href);
    copyStatus.textContent = "Link berhasil disalin.";
  } catch {
    copyStatus.textContent = "Tidak dapat menyalin otomatis. Silakan salin link secara manual.";
  }
});